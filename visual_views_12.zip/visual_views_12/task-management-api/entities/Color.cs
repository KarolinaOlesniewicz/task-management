﻿namespace task_management_api.entities
{
    public class Color
    {
        public int Id { get; set; }
        public string ColorName { get; set; }
    }
}
