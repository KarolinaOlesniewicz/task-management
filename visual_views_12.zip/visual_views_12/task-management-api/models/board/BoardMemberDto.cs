﻿namespace task_management_api.models.board
{
    public class BoardMemberDto
    {
        public int UserId { get; set; }
        public int BoardId { get; set; }
    }
}
