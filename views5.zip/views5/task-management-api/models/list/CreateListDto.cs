﻿namespace task_management_api.models.list
{
    public class CreateListDto
    {
        public string Name { get; set; }
        public int Position { get; set; }
    }
}
