﻿namespace task_management_api.models.user
{
    public class UserLogInDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
